##James Lee - jl5241

You can run the test by loding this whole file
and then running the tests script.
Please make sure that your default directory is this folder.
For example, the test script loads the CSVDataTable by calling
from src import CSVDataTable
If your working diretory is not this folder, then this is going to fail.
Otherwise, everything should run smoothly.

