##James Lee - jl5241
W4111_HW2
You can run the test by first booting up the application then
going to aeneid -> tests -> run
The output should all go into testoutput -> restlog.txt
I ran all the test that professor Ferguson posted online, and got the same results that he posted.



